package com.masroofalbait.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String TYPE = "type";
    public static final String DAILY = "daily";
    public static final String DUE = "due";
    public static final String PRE_DUE = "pre_due";
    private static final String CHANNEL_ID = "masroof_reminders";

    @Override public void onReceive(Context context, Intent intent) {
        String type = intent.getStringExtra(TYPE);
        createChannel(context);
        String title;
        String text;
        if (PRE_DUE.equals(type)) {
            title = "تذكير مبكر بالالتزامات";
            text = "غدًا موعد القسط والإيجار. جهّز المبلغ قبل الاستحقاق.";
        } else if (DUE.equals(type)) {
            title = "موعد القسط والإيجار";
            text = "اليوم موعد الالتزامات الشهرية المسجلة في برنامج مصروف البيت.";
        } else {
            title = "مصروف البيت";
            text = "لا تنسَ تسجيل مصاريف اليوم حتى تبقى ميزانيتك دقيقة.";
        }
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(context, CHANNEL_ID)
                : new android.app.Notification.Builder(context);
        b.setSmallIcon(com.masroofalbait.app.R.drawable.ic_notification)
         .setContentTitle(title).setContentText(text).setAutoCancel(true)
         .setStyle(new android.app.Notification.BigTextStyle().bigText(text));
        nm.notify(type == null ? 100 : type.hashCode(), b.build());
        if (DAILY.equals(type)) scheduleDaily(context);
        else if (DUE.equals(type)) scheduleMonthly(context, DUE, 1, 9, 0);
        else if (PRE_DUE.equals(type)) schedulePreDue(context);
    }

    public static void scheduleAll(Context c) {
        scheduleDaily(c);
        scheduleMonthly(c, DUE, 1, 9, 0);
        schedulePreDue(c);
    }

    private static void schedulePreDue(Context c) {
        Calendar nextDue = Calendar.getInstance();
        nextDue.set(Calendar.DAY_OF_MONTH, 1);
        nextDue.set(Calendar.HOUR_OF_DAY, 9); nextDue.set(Calendar.MINUTE, 0); nextDue.set(Calendar.SECOND, 0); nextDue.set(Calendar.MILLISECOND, 0);
        if (nextDue.getTimeInMillis() <= System.currentTimeMillis()) nextDue.add(Calendar.MONTH, 1);
        nextDue.add(Calendar.DAY_OF_MONTH, -3);
        scheduleAt(c, PRE_DUE, nextDue);
    }

    private static void scheduleDaily(Context c) {
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, 20); next.set(Calendar.MINUTE, 0); next.set(Calendar.SECOND, 0); next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_MONTH, 1);
        scheduleAt(c, DAILY, next);
    }

    private static void scheduleMonthly(Context c, String type, int day, int hour, int minute) {
        Calendar next = Calendar.getInstance();
        next.set(Calendar.DAY_OF_MONTH, day);
        next.set(Calendar.HOUR_OF_DAY, hour); next.set(Calendar.MINUTE, minute); next.set(Calendar.SECOND, 0); next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) {
            next.add(Calendar.MONTH, 1);
            next.set(Calendar.DAY_OF_MONTH, day);
        }
        scheduleAt(c, type, next);
    }

    private static void scheduleAt(Context c, String type, Calendar when) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, ReminderReceiver.class).putExtra(TYPE, type);
        int request = type.hashCode();
        PendingIntent pi = PendingIntent.getBroadcast(c, request, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        else am.set(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
    }

    private static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "تذكيرات مصروف البيت", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("تذكيرات المصاريف والأقساط");
            nm.createNotificationChannel(ch);
        }
    }
}
