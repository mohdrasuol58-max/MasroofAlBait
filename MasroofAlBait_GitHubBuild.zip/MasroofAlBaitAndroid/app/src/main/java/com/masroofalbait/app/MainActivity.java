package com.masroofalbait.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler handler = new Handler();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,31,58));
        getWindow().setNavigationBarColor(Color.rgb(11,31,58));
        showSplash();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 501);
        } else {
            ReminderReceiver.scheduleAll(this);
        }
    }

    private void showSplash() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setPadding(28,28,28,28);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(11,31,58), Color.rgb(23,55,96)});
        splash.setBackground(bg);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_launcher);
        splash.addView(icon, new LinearLayout.LayoutParams(118,118));

        TextView title = new TextView(this);
        title.setText("مصروف البيت"); title.setTextColor(Color.WHITE); title.setTextSize(30); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER); title.setPadding(0,18,0,4);
        splash.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("إدارة دخلك ومصاريف بيتك بسهولة"); sub.setTextColor(Color.rgb(208,220,236)); sub.setTextSize(15); sub.setGravity(Gravity.CENTER);
        splash.addView(sub, new LinearLayout.LayoutParams(-1, -2));

        TextView loading = new TextView(this);
        loading.setText("جارٍ تجهيز ميزانيتك…"); loading.setTextColor(Color.rgb(244,185,66)); loading.setTextSize(13); loading.setGravity(Gravity.CENTER); loading.setPadding(0,28,0,0);
        splash.addView(loading, new LinearLayout.LayoutParams(-1, -2));
        setContentView(splash);

        handler.postDelayed(this::showApp, 850);
    }

    private void showApp() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244,247,251));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 501) ReminderReceiver.scheduleAll(this);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
